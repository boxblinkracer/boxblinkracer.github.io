<?php

namespace App\Controller;

use App\Service\DemoService;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class TestController extends AbstractController
{

    /**
     * @var DemoService
     */
    private $demoService;


    /**
     * @param DemoService $demoService
     */
    public function __construct(DemoService $demoService)
    {
        $this->demoService = $demoService;
    }


    /**
     * @return Response
     */
    #[Route('/demo', name: 'demo')]
    public function index(): Response
    {
        echo "Symfony Demo Application";
        die();
    }

}