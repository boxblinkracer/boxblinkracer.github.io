<?php

namespace App\Service;

class DemoService
{

    /**
     * @var string
     */
    private $apiKey;


    /**
     * @param string $apiKey
     */
    public function __construct(string $apiKey)
    {
        $this->apiKey = $apiKey;
    }

    /**
     * @return string
     */
    public function getApiKey(): string
    {
        return $this->apiKey;
    }

}